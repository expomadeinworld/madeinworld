--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Homebrew)
-- Dumped by pg_dump version 14.18 (Homebrew)

-- Started on 2025-07-09 21:33:11 CEST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS madeinworld;
--
-- TOC entry 4050 (class 1262 OID 16384)
-- Name: madeinworld; Type: DATABASE; Schema: -; Owner: imsolesong
--

CREATE DATABASE madeinworld WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE madeinworld OWNER TO imsolesong;

\connect madeinworld

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 895 (class 1247 OID 16821)
-- Name: mini_app_type; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.mini_app_type AS ENUM (
    'RetailStore',
    'UnmannedStore',
    'ExhibitionSales',
    'GroupBuying'
);


ALTER TYPE public.mini_app_type OWNER TO imsolesong;

--
-- TOC entry 874 (class 1247 OID 16448)
-- Name: notification_reference_type; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.notification_reference_type AS ENUM (
    'StockRequest',
    'Shipment',
    'Order'
);


ALTER TYPE public.notification_reference_type OWNER TO imsolesong;

--
-- TOC entry 871 (class 1247 OID 16440)
-- Name: shipment_status; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.shipment_status AS ENUM (
    'Assigned',
    'Picked Up',
    'Delivered'
);


ALTER TYPE public.shipment_status OWNER TO imsolesong;

--
-- TOC entry 868 (class 1247 OID 16424)
-- Name: stock_request_status; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.stock_request_status AS ENUM (
    'Pending',
    'Confirmed by Manufacturer',
    'Ready for Pickup',
    'In Transit',
    'Delivered',
    'Verified',
    'Cancelled'
);


ALTER TYPE public.stock_request_status OWNER TO imsolesong;

--
-- TOC entry 862 (class 1247 OID 16408)
-- Name: store_type; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.store_type AS ENUM (
    'Retail',
    'Unmanned',
    'Warehouse',
    '无人商店',
    '展销商店',
    '展销商城',
    '无人门店',
    '无人仓店'
);


ALTER TYPE public.store_type OWNER TO imsolesong;

--
-- TOC entry 865 (class 1247 OID 16416)
-- Name: store_type_association; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.store_type_association AS ENUM (
    'Retail',
    'Unmanned',
    'All'
);


ALTER TYPE public.store_type_association OWNER TO imsolesong;

--
-- TOC entry 859 (class 1247 OID 16397)
-- Name: user_role; Type: TYPE; Schema: public; Owner: imsolesong
--

CREATE TYPE public.user_role AS ENUM (
    'Customer',
    'Admin',
    'Manufacturer',
    '3PL',
    'Partner'
);


ALTER TYPE public.user_role OWNER TO imsolesong;

--
-- TOC entry 246 (class 1255 OID 16858)
-- Name: update_subcategories_updated_at(); Type: FUNCTION; Schema: public; Owner: imsolesong
--

CREATE FUNCTION public.update_subcategories_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_subcategories_updated_at() OWNER TO imsolesong;

--
-- TOC entry 245 (class 1255 OID 16656)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: imsolesong
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO imsolesong;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 228 (class 1259 OID 16921)
-- Name: carts; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.carts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT carts_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.carts OWNER TO imsolesong;

--
-- TOC entry 234 (class 1259 OID 17033)
-- Name: inventory; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    product_id integer,
    store_id integer,
    quantity integer DEFAULT 0 NOT NULL,
    reserved_quantity integer DEFAULT 0 NOT NULL,
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory OWNER TO imsolesong;

--
-- TOC entry 233 (class 1259 OID 17032)
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inventory_inventory_id_seq OWNER TO imsolesong;

--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 233
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- TOC entry 211 (class 1259 OID 16469)
-- Name: manufacturers; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.manufacturers (
    manufacturer_id integer NOT NULL,
    company_name character varying(255) NOT NULL,
    contact_person character varying(255),
    contact_email character varying(255),
    address text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.manufacturers OWNER TO imsolesong;

--
-- TOC entry 210 (class 1259 OID 16468)
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.manufacturers_manufacturer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manufacturers_manufacturer_id_seq OWNER TO imsolesong;

--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 210
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.manufacturers_manufacturer_id_seq OWNED BY public.manufacturers.manufacturer_id;


--
-- TOC entry 219 (class 1259 OID 16635)
-- Name: notifications; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.notifications (
    notification_id integer NOT NULL,
    recipient_user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    reference_type public.notification_reference_type,
    reference_id integer,
    is_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notifications OWNER TO imsolesong;

--
-- TOC entry 218 (class 1259 OID 16634)
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.notifications_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_notification_id_seq OWNER TO imsolesong;

--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 218
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.notifications_notification_id_seq OWNED BY public.notifications.notification_id;


--
-- TOC entry 230 (class 1259 OID 16957)
-- Name: order_items; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    price numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT order_items_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.order_items OWNER TO imsolesong;

--
-- TOC entry 229 (class 1259 OID 16941)
-- Name: orders; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'confirmed'::character varying, 'processing'::character varying, 'shipped'::character varying, 'delivered'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT orders_total_amount_check CHECK ((total_amount >= (0)::numeric))
);


ALTER TABLE public.orders OWNER TO imsolesong;

--
-- TOC entry 213 (class 1259 OID 16482)
-- Name: partners; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.partners (
    partner_id integer NOT NULL,
    user_id uuid NOT NULL,
    region_assigned character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.partners OWNER TO imsolesong;

--
-- TOC entry 212 (class 1259 OID 16481)
-- Name: partners_partner_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.partners_partner_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.partners_partner_id_seq OWNER TO imsolesong;

--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 212
-- Name: partners_partner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.partners_partner_id_seq OWNED BY public.partners.partner_id;


--
-- TOC entry 217 (class 1259 OID 16508)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.product_categories (
    category_id integer NOT NULL,
    name character varying(255) NOT NULL,
    store_type_association public.store_type_association DEFAULT 'All'::public.store_type_association NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    mini_app_association public.mini_app_type[] DEFAULT ARRAY['RetailStore'::public.mini_app_type],
    store_id integer,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true
);


ALTER TABLE public.product_categories OWNER TO imsolesong;

--
-- TOC entry 216 (class 1259 OID 16507)
-- Name: product_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.product_categories_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_categories_category_id_seq OWNER TO imsolesong;

--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 216
-- Name: product_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.product_categories_category_id_seq OWNED BY public.product_categories.category_id;


--
-- TOC entry 231 (class 1259 OID 17012)
-- Name: product_category_mapping; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.product_category_mapping (
    product_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.product_category_mapping OWNER TO imsolesong;

--
-- TOC entry 226 (class 1259 OID 16889)
-- Name: product_images; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.product_images (
    image_id integer NOT NULL,
    product_id integer NOT NULL,
    image_url character varying(500) NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_primary boolean DEFAULT false
);


ALTER TABLE public.product_images OWNER TO imsolesong;

--
-- TOC entry 225 (class 1259 OID 16888)
-- Name: product_images_image_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.product_images_image_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_images_image_id_seq OWNER TO imsolesong;

--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 225
-- Name: product_images_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.product_images_image_id_seq OWNED BY public.product_images.image_id;


--
-- TOC entry 232 (class 1259 OID 17022)
-- Name: product_subcategory_mapping; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.product_subcategory_mapping (
    product_id integer NOT NULL,
    subcategory_id integer NOT NULL
);


ALTER TABLE public.product_subcategory_mapping OWNER TO imsolesong;

--
-- TOC entry 224 (class 1259 OID 16861)
-- Name: products; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    sku character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    description_short text,
    description_long text,
    manufacturer_id integer,
    store_type public.store_type NOT NULL,
    store_id integer,
    main_price numeric(10,2) NOT NULL,
    strikethrough_price numeric(10,2),
    stock_left integer DEFAULT 0,
    minimum_order_quantity integer DEFAULT 1,
    cost_price numeric(10,2),
    is_active boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    is_mini_app_recommendation boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    product_uuid uuid DEFAULT gen_random_uuid() NOT NULL,
    mini_app_type character varying(50)
);


ALTER TABLE public.products OWNER TO imsolesong;

--
-- TOC entry 223 (class 1259 OID 16860)
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO imsolesong;

--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 223
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- TOC entry 215 (class 1259 OID 16496)
-- Name: stores; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.stores (
    store_id integer NOT NULL,
    name character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    address text NOT NULL,
    latitude numeric(10,8) NOT NULL,
    longitude numeric(11,8) NOT NULL,
    type public.store_type NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    image_url character varying(500)
);


ALTER TABLE public.stores OWNER TO imsolesong;

--
-- TOC entry 214 (class 1259 OID 16495)
-- Name: stores_store_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.stores_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stores_store_id_seq OWNER TO imsolesong;

--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 214
-- Name: stores_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.stores_store_id_seq OWNED BY public.stores.store_id;


--
-- TOC entry 222 (class 1259 OID 16830)
-- Name: subcategories; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.subcategories (
    subcategory_id integer NOT NULL,
    parent_category_id integer NOT NULL,
    name character varying(255) NOT NULL,
    image_url character varying(500),
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.subcategories OWNER TO imsolesong;

--
-- TOC entry 221 (class 1259 OID 16829)
-- Name: subcategories_subcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: imsolesong
--

CREATE SEQUENCE public.subcategories_subcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subcategories_subcategory_id_seq OWNER TO imsolesong;

--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 221
-- Name: subcategories_subcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: imsolesong
--

ALTER SEQUENCE public.subcategories_subcategory_id_seq OWNED BY public.subcategories.subcategory_id;


--
-- TOC entry 227 (class 1259 OID 16904)
-- Name: users; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    phone character varying(20),
    first_name character varying(100),
    last_name character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO imsolesong;

--
-- TOC entry 220 (class 1259 OID 16664)
-- Name: users_backup; Type: TABLE; Schema: public; Owner: imsolesong
--

CREATE TABLE public.users_backup (
    user_id uuid,
    phone_number character varying(20),
    password_hash character varying(255),
    full_name character varying(255),
    email character varying(255),
    avatar_url character varying(500),
    role public.user_role,
    created_at timestamp with time zone,
    last_login timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.users_backup OWNER TO imsolesong;

--
-- TOC entry 3793 (class 2604 OID 17036)
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- TOC entry 3737 (class 2604 OID 16472)
-- Name: manufacturers manufacturer_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.manufacturers ALTER COLUMN manufacturer_id SET DEFAULT nextval('public.manufacturers_manufacturer_id_seq'::regclass);


--
-- TOC entry 3754 (class 2604 OID 16638)
-- Name: notifications notification_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.notifications ALTER COLUMN notification_id SET DEFAULT nextval('public.notifications_notification_id_seq'::regclass);


--
-- TOC entry 3740 (class 2604 OID 16485)
-- Name: partners partner_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.partners ALTER COLUMN partner_id SET DEFAULT nextval('public.partners_partner_id_seq'::regclass);


--
-- TOC entry 3747 (class 2604 OID 16511)
-- Name: product_categories category_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_categories ALTER COLUMN category_id SET DEFAULT nextval('public.product_categories_category_id_seq'::regclass);


--
-- TOC entry 3772 (class 2604 OID 16892)
-- Name: product_images image_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_images ALTER COLUMN image_id SET DEFAULT nextval('public.product_images_image_id_seq'::regclass);


--
-- TOC entry 3762 (class 2604 OID 16864)
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- TOC entry 3743 (class 2604 OID 16499)
-- Name: stores store_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.stores ALTER COLUMN store_id SET DEFAULT nextval('public.stores_store_id_seq'::regclass);


--
-- TOC entry 3757 (class 2604 OID 16833)
-- Name: subcategories subcategory_id; Type: DEFAULT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.subcategories ALTER COLUMN subcategory_id SET DEFAULT nextval('public.subcategories_subcategory_id_seq'::regclass);


--
-- TOC entry 4038 (class 0 OID 16921)
-- Dependencies: 228
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.carts (id, user_id, product_id, quantity, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4044 (class 0 OID 17033)
-- Dependencies: 234
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.inventory (inventory_id, product_id, store_id, quantity, reserved_quantity, last_updated) FROM stdin;
\.


--
-- TOC entry 4021 (class 0 OID 16469)
-- Dependencies: 211
-- Data for Name: manufacturers; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.manufacturers (manufacturer_id, company_name, contact_person, contact_email, address, created_at, updated_at) FROM stdin;
1	Coca-Cola Company	John Smith	contact@coca-cola.com	Atlanta, GA, USA	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
2	Barilla Group	Marco Rossi	contact@barilla.com	Parma, Italy	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
3	Alpine Springs	Hans Mueller	contact@alpinesprings.ch	Swiss Alps, Switzerland	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
4	Lindt & Sprüngli	Pierre Dubois	contact@lindt.com	Kilchberg, Switzerland	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
5	Swiss Dairy Co.	Anna Weber	contact@swissdairy.ch	Bern, Switzerland	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
6	Mountain Honey	Klaus Fischer	contact@mountainhoney.ch	Graubünden, Switzerland	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
7	Swiss Timepieces	Jean-Claude Biver	contact@swisstimepieces.ch	Geneva, Switzerland	2025-07-08 17:31:06.538749+02	2025-07-08 17:31:06.538749+02
\.


--
-- TOC entry 4029 (class 0 OID 16635)
-- Dependencies: 219
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.notifications (notification_id, recipient_user_id, title, message, reference_type, reference_id, is_read, created_at) FROM stdin;
\.


--
-- TOC entry 4040 (class 0 OID 16957)
-- Dependencies: 230
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.order_items (id, order_id, product_id, quantity, price, created_at) FROM stdin;
\.


--
-- TOC entry 4039 (class 0 OID 16941)
-- Dependencies: 229
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.orders (id, user_id, total_amount, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4023 (class 0 OID 16482)
-- Dependencies: 213
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.partners (partner_id, user_id, region_assigned, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4027 (class 0 OID 16508)
-- Dependencies: 217
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.product_categories (category_id, name, store_type_association, created_at, updated_at, mini_app_association, store_id, display_order, is_active) FROM stdin;
5	Chanteclair	All	2025-07-08 19:12:20.980621+02	2025-07-08 19:15:57.555+02	{RetailStore}	\N	1	f
6	Chanteclair	All	2025-07-08 19:16:03.439998+02	2025-07-08 19:16:03.439998+02	{RetailStore}	\N	1	t
7	MAXI	All	2025-07-09 18:42:07.106632+02	2025-07-09 18:42:07.106632+02	{RetailStore}	\N	2	t
8	Chanteclair	All	2025-07-09 18:44:16.714573+02	2025-07-09 18:44:33.300232+02	{UnmannedStore}	7	1	t
9	Chanteclair	All	2025-07-09 18:45:31.083421+02	2025-07-09 18:45:31.083421+02	{UnmannedStore}	10	1	t
10	Chanteclair	All	2025-07-09 18:49:41.216251+02	2025-07-09 18:49:41.216251+02	{UnmannedStore}	11	1	t
11	Chanteclair	All	2025-07-09 18:50:29.748183+02	2025-07-09 18:50:29.748183+02	{UnmannedStore}	12	1	t
1	展销商品	All	2025-07-08 16:57:21.598729+02	2025-07-09 18:51:53.391183+02	{ExhibitionSales}	\N	0	f
3	特色产品	All	2025-07-08 16:57:21.598729+02	2025-07-09 18:51:55.503144+02	{ExhibitionSales,GroupBuying}	\N	0	f
12	MAXI	All	2025-07-09 18:52:14.056733+02	2025-07-09 18:52:14.056733+02	{ExhibitionSales}	13	1	t
13	MAXI	All	2025-07-09 18:53:03.429152+02	2025-07-09 18:53:03.429152+02	{ExhibitionSales}	14	1	t
14	MAXI	All	2025-07-09 18:53:41.433037+02	2025-07-09 18:53:41.433037+02	{ExhibitionSales}	15	1	t
15	MAXI	All	2025-07-09 18:55:11.27344+02	2025-07-09 18:55:11.27344+02	{ExhibitionSales}	16	1	t
2	团购商品	All	2025-07-08 16:57:21.598729+02	2025-07-09 18:59:52.990595+02	{GroupBuying}	\N	0	f
4	限时优惠	All	2025-07-08 16:57:21.598729+02	2025-07-09 18:59:54.759784+02	{GroupBuying}	\N	0	f
16	LEVISSIMA	All	2025-07-09 19:02:08.043811+02	2025-07-09 19:02:08.043811+02	{GroupBuying}	\N	1	t
\.


--
-- TOC entry 4041 (class 0 OID 17012)
-- Dependencies: 231
-- Data for Name: product_category_mapping; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.product_category_mapping (product_id, category_id) FROM stdin;
9	6
10	6
11	7
12	8
13	9
14	10
15	11
16	12
17	13
18	14
19	15
20	16
\.


--
-- TOC entry 4036 (class 0 OID 16889)
-- Dependencies: 226
-- Data for Name: product_images; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.product_images (image_id, product_id, image_url, display_order, created_at, is_primary) FROM stdin;
8	9	http://localhost:8080/uploads/products/9_1752081489182718000_9_1752081156210726000_chanteclair-sgrassatore-marsiglia-spray-600-ml.jpeg	1	2025-07-09 19:18:09.184598+02	t
10	10	http://localhost:8080/uploads/products/10_1752083702437253000_8015194517892-070.png	1	2025-07-09 19:55:02.441086+02	t
11	11	http://localhost:8080/uploads/products/11_1752083759334633000_Mock-up-Carta-Igienica-4-ROTOLI-GIGANTI-2500-strappi.png	1	2025-07-09 19:55:59.340405+02	t
12	12	http://localhost:8080/uploads/products/12_1752083826322836000_Chanteclair-Lavatrice-Pulito-Profondo.png	1	2025-07-09 19:57:06.324603+02	t
13	13	http://localhost:8080/uploads/products/13_1752083903460908000_chanteclair-i-concentrati-ammorbidente-muschio-bianco-1000-ml.png	1	2025-07-09 19:58:23.463871+02	t
14	14	http://localhost:8080/uploads/products/14_1752086400583909000_61Cp-JR-8tL.jpg	1	2025-07-09 20:40:00.588273+02	t
15	15	http://localhost:8080/uploads/products/15_1752086457469061000_c00t00c00045.jpeg	1	2025-07-09 20:40:57.471064+02	t
16	16	http://localhost:8080/uploads/products/16_1752086583912446000_m00x00c00013.jpeg	1	2025-07-09 20:43:03.914091+02	t
17	17	http://localhost:8080/uploads/products/17_1752086621175361000_m00x00c00019.jpeg	1	2025-07-09 20:43:41.176614+02	t
18	18	http://localhost:8080/uploads/products/18_1752086671661083000_m00x00c00026.jpeg	1	2025-07-09 20:44:31.662497+02	t
19	19	http://localhost:8080/uploads/products/19_1752086779569707000_m00x00c00029.jpeg	1	2025-07-09 20:46:19.571508+02	t
20	20	http://localhost:8080/uploads/products/20_1752086822831018000_l00v00s00001.jpeg	1	2025-07-09 20:47:02.83196+02	t
\.


--
-- TOC entry 4042 (class 0 OID 17022)
-- Dependencies: 232
-- Data for Name: product_subcategory_mapping; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.product_subcategory_mapping (product_id, subcategory_id) FROM stdin;
9	32
10	33
11	34
12	35
13	36
14	37
15	38
16	39
17	40
18	41
19	42
20	43
\.


--
-- TOC entry 4034 (class 0 OID 16861)
-- Dependencies: 224
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.products (product_id, sku, title, description_short, description_long, manufacturer_id, store_type, store_id, main_price, strikethrough_price, stock_left, minimum_order_quantity, cost_price, is_active, is_featured, is_mini_app_recommendation, created_at, updated_at, product_uuid, mini_app_type) FROM stdin;
18	m00x00c00026	MAXI la Supercarta * 400 Tovaglioli Monovelo Compatto * 33 x 33		MAXI la Supercarta * 400 Tovaglioli Monovelo Compatto * 33 x 33	1	展销商店	15	3.99	5.99	0	2	1.29	t	f	t	2025-07-09 20:44:28.295047+02	2025-07-09 20:45:33.719325+02	cfb080c8-8b8e-455c-98ce-f1a49bdf63c9	ExhibitionSales
19	m00x00c00029	MAXI la Supercarta * Fazzoletti 3 Veli * 9 Fazzoletti per Pacchetto * 10 Pacchetti Morbidissimi		MAXI la Supercarta * Fazzoletti 3 Veli * 9 Fazzoletti per Pacchetto * 10 Pacchetti Morbidissimi	1	展销商店	16	2.19	4.99	0	1	0.99	t	t	t	2025-07-09 20:46:15.090499+02	2025-07-09 20:46:15.090499+02	451149c0-acaf-4646-85ea-7665c6dcf5b6	ExhibitionSales
20	l00v00s00001	LEVISSIMA Naturale * 100% R-PET * Bottiglia 6 x 50 cL		LEVISSIMA Naturale * 100% R-PET * Bottiglia 6 x 50 cL	1	展销商店	\N	2.59	3.50	0	2	2.20	t	f	t	2025-07-09 20:46:59.320583+02	2025-07-09 20:46:59.320583+02	081042fa-9da4-4b26-abbb-ff6a23240593	GroupBuying
9	c00t00c00001	Sgrassatore Universale Marsiglia		Sgrassatore Universale Marsiglia	1	展销商店	\N	2.99	4.99	0	1	1.59	t	f	t	2025-07-09 19:11:14.972846+02	2025-07-09 19:19:35.435218+02	a51669fe-c415-4241-8c94-e5f1601e4328	RetailStore
10	c00t00c00009	Anticalcare Universale Antigoccia		Anticalcare Universale Antigoccia	1	展销商店	\N	4.99	8.99	0	2	2.59	t	f	t	2025-07-09 19:54:25.959234+02	2025-07-09 19:54:25.959234+02	fea1e3d0-e912-4fd1-8037-999c64267789	RetailStore
11	m00x00c00001	MAXI la Supercarta * Carta Igienica 4 Rotoli Giganti 2500 x 2 Veli * 2500 Strappi		MAXI la Supercarta * Carta Igienica 4 Rotoli Giganti 2500 x 2 Veli * 2500 Strappi	1	展销商店	\N	4.99	6.59	0	1	2.10	t	f	f	2025-07-09 19:55:40.181219+02	2025-07-09 19:55:40.181219+02	a38e6599-eaf4-4651-8ae6-f7f9d2ffca59	RetailStore
12	c00t00c00020	Detersivo per Lavatrice Pulito Profondo		Detersivo per Lavatrice Pulito Profondo	1	无人门店	7	2.99	5.99	95	1	1.99	t	t	t	2025-07-09 19:56:42.051038+02	2025-07-09 20:38:37.452009+02	dd53ac1b-6eff-4bab-a405-b0c1edc9aa4c	UnmannedStore
13	c00t00c00026	Ammorbidenti i Concentrati Muschio Bianco		Ammorbidenti i Concentrati Muschio Bianco	1	无人门店	10	2.99	5.99	57	1	1.50	t	t	t	2025-07-09 19:57:49.623424+02	2025-07-09 20:38:46.28264+02	79c41e72-f9a3-4c54-a877-27cf9d43993f	UnmannedStore
14	c00t00c00034	Profuma Biancheria i Concentrati Muschio Bianco		Profuma Biancheria i Concentrati Muschio Bianco	1	无人仓店	11	4.99	8.59	39	2	2.99	t	t	t	2025-07-09 20:39:34.240335+02	2025-07-09 20:39:34.240335+02	abfc9784-ff5f-46fa-97e9-f4e8e3330409	UnmannedStore
15	c00t00c00045	Detersivo Capi Sportivi e Fibre Sintetiche		Detersivo Capi Sportivi e Fibre Sintetiche	1	无人仓店	12	3.99	5.99	28	2	1.29	t	f	t	2025-07-09 20:40:44.277179+02	2025-07-09 20:40:44.277179+02	2e354aec-9dbf-45ea-8fb3-864bc97dadba	UnmannedStore
16	m00x00c00013	MAXI la Supercarta * Asciugatutto 1 Rotolo Decorato x 2 Veli * 135 Strappi		MAXI la Supercarta * Asciugatutto 1 Rotolo Decorato x 2 Veli * 135 Strappi	1	展销商城	13	3.99	5.99	0	3	1.99	t	t	f	2025-07-09 20:43:00.274598+02	2025-07-09 20:43:00.274598+02	52da3800-52ae-4df7-8715-e1eec32f5f74	ExhibitionSales
17	m00x00c00019	MAXI la Supercarta * BOBINOTTO 1 Rotolo Super Compatto x 2 Veli 		MAXI la Supercarta * BOBINOTTO 1 Rotolo Super Compatto x 2 Veli	1	展销商城	14	2.99	4.99	0	3	1.99	t	t	t	2025-07-09 20:43:37.548439+02	2025-07-09 20:43:37.548439+02	1995d0ec-6273-4424-9070-21e2313f4d2f	ExhibitionSales
\.


--
-- TOC entry 4025 (class 0 OID 16496)
-- Dependencies: 215
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.stores (store_id, name, city, address, latitude, longitude, type, is_active, created_at, updated_at, image_url) FROM stdin;
3	Test Store	Test City	Test Address	45.00000000	9.00000000	无人商店	f	2025-07-08 18:29:54.7189+02	2025-07-08 18:29:54.7189+02	\N
4	Active Test Store	Active Test City	Active Test Address	45.00000000	9.00000000	无人商店	f	2025-07-08 18:35:44.326783+02	2025-07-08 18:38:45.649361+02	\N
5	Active Test Store	Active Test City	Active Test Address	45.00000000	9.00000000	无人商店	f	2025-07-08 18:36:32.895957+02	2025-07-08 18:38:47.398815+02	\N
6	Active Test Store	Active Test City	Active Test Address	45.00000000	9.00000000	无人商店	f	2025-07-08 18:36:53.161647+02	2025-07-08 18:38:49.03759+02	\N
8	Test Store	Test City	Test Address	45.00000000	9.00000000	无人门店	f	2025-07-08 18:43:53.623591+02	2025-07-08 18:46:47.801169+02	\N
9	Test 无人仓店	Test City	Test Address	45.00000000	9.00000000	无人仓店	f	2025-07-08 18:45:35.776306+02	2025-07-08 18:46:49.3855+02	\N
7	MANOR Lugano	Lugano	Salita M. e A. Chiattone 10, 6900 Lugano	46.00516436	8.95039408	无人门店	t	2025-07-08 18:40:36.148881+02	2025-07-08 18:49:46.196806+02	/uploads/stores/store_7_1751993386_MANORLugano.png
10	Molino Nuovo	Lugano	Via Monte Boglia 5, 6900 Lugano	46.01863606	8.95863070	无人门店	t	2025-07-08 18:51:26.163521+02	2025-07-08 18:52:09.61561+02	/uploads/stores/store_10_1751993529_MolinoNuovo.jpg
11	Viganello	Lugano	Via Molinazzo 1, 6962 Lugano	46.01021036	8.96450061	无人仓店	t	2025-07-08 18:52:55.501073+02	2025-07-08 18:53:41.647376+02	/uploads/stores/store_11_1751993621_Viganello.png
12	Pregassona	Lugano	Viale Cassone 3, 6963 Lugano	46.02053951	8.96826120	无人仓店	t	2025-07-08 18:54:19.447648+02	2025-07-08 18:54:58.924243+02	/uploads/stores/store_12_1751993698_Pregassona.png
13	Chiodenda	Agno	Via Chiodenda 7, 6982 Agno	45.99895056	8.90354473	展销商城	t	2025-07-08 18:56:05.750224+02	2025-07-08 18:57:20.283284+02	/uploads/stores/store_13_1751993840_Chiodenda.png
14	Ceresio	Lugano	Via Ceresio 40, 6963 Lugano	46.02149595	8.96643840	展销商城	t	2025-07-08 18:58:07.224021+02	2025-07-08 18:59:38.743408+02	/uploads/stores/store_14_1751993978_Ceresio.png
15	Porta di Roma	Roma	Via Alberto Lionello, 221, 00139 Roma RM, Italy	41.97236997	12.53906033	展销商店	t	2025-07-08 19:00:21.637715+02	2025-07-08 19:03:19.316415+02	/uploads/stores/store_15_1751994158_PortadiRoma.png
16	ROMAEST	Roma	V. Collatina, Km 12.800, 00132 Roma RM, Italy	41.91390471	12.66100012	展销商店	t	2025-07-08 19:01:38.770602+02	2025-07-08 19:03:24.151277+02	/uploads/stores/store_16_1751994161_Romaest.png
\.


--
-- TOC entry 4032 (class 0 OID 16830)
-- Dependencies: 222
-- Data for Name: subcategories; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.subcategories (subcategory_id, parent_category_id, name, image_url, display_order, is_active, created_at, updated_at) FROM stdin;
22	1	地方特产	https://via.placeholder.com/150/FFF5F5/D92525?text=地方特产	1	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
23	1	手工艺品	https://via.placeholder.com/150/FFF5F5/D92525?text=手工艺品	2	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
24	1	文化用品	https://via.placeholder.com/150/FFF5F5/D92525?text=文化用品	3	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
25	2	批发商品	https://via.placeholder.com/150/FFF5F5/D92525?text=批发商品	1	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
26	2	团购套餐	https://via.placeholder.com/150/FFF5F5/D92525?text=团购套餐	2	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
27	2	企业采购	https://via.placeholder.com/150/FFF5F5/D92525?text=企业采购	3	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
28	3	季节限定	https://via.placeholder.com/150/FFF5F5/D92525?text=季节限定	1	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
29	3	新品推荐	https://via.placeholder.com/150/FFF5F5/D92525?text=新品推荐	2	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
30	4	秒杀商品	https://via.placeholder.com/150/FFF5F5/D92525?text=秒杀商品	1	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
31	4	拼团优惠	https://via.placeholder.com/150/FFF5F5/D92525?text=拼团优惠	2	t	2025-07-08 16:57:21.599558+02	2025-07-08 16:57:21.599558+02
32	6	Sgrassatori	/uploads/subcategories/subcategory_32_1751995093_Chante-Clair-sgrassatore-universale-625-ml-profumi-vari.jpg	1	t	2025-07-08 19:18:13.85724+02	2025-07-08 19:18:13.86369+02
33	6	Bagno & Anticalcare	/uploads/subcategories/subcategory_33_1752079287_71bUuPB9x9L._AC_SL1466_.jpg	2	t	2025-07-09 18:41:27.872813+02	2025-07-09 18:41:27.883058+02
34	7	Carta Igienica	/uploads/subcategories/subcategory_34_1752079430_104762-001_01__55387.jpeg	1	t	2025-07-09 18:43:50.719809+02	2025-07-09 18:43:50.72783+02
35	8	Detersivi per Lavatrice	/uploads/subcategories/subcategory_35_1752079521_81LsdSqTGkL._AC_SL1500_.jpg	1	t	2025-07-09 18:45:21.404347+02	2025-07-09 18:45:21.414594+02
36	9	Ammorbidenti	/uploads/subcategories/subcategory_36_1752079773_Ammorbidenti.jpeg	1	t	2025-07-09 18:49:33.711576+02	2025-07-09 18:49:33.719272+02
37	10	Profuma Bucato	/uploads/subcategories/subcategory_37_1752079823_i-concentrati-chanteclair-profuma-biancheria-jpg.jpeg	1	t	2025-07-09 18:50:23.79306+02	2025-07-09 18:50:23.800623+02
38	11	Bucato a Mano	/uploads/subcategories/subcategory_38_1752079901_Detersivi-per-lavatrice-Chanteclair.png	1	t	2025-07-09 18:51:41.201378+02	2025-07-09 18:51:41.209191+02
39	12	Asciugatutto	/uploads/subcategories/subcategory_39_1752079978_104769-001_01__89610.jpeg	1	t	2025-07-09 18:52:58.639605+02	2025-07-09 18:52:58.645282+02
40	13	Bobine	/uploads/subcategories/subcategory_40_1752080016_Bobine.png	1	t	2025-07-09 18:53:36.095623+02	2025-07-09 18:53:36.102867+02
41	14	Tovaglioli	/uploads/subcategories/subcategory_41_1752080105_104765-001_01__34305.jpeg	1	t	2025-07-09 18:55:05.094194+02	2025-07-09 18:55:05.101572+02
42	15	Fazzoletti & Veline	/uploads/subcategories/subcategory_42_1752080375_fazzoletti.jpeg	1	t	2025-07-09 18:59:35.655555+02	2025-07-09 18:59:35.659348+02
43	16	LE NATURALI	/uploads/subcategories/subcategory_43_1752080806_Levissima_acqua_naturale_0.jpeg	1	t	2025-07-09 19:06:46.62509+02	2025-07-09 19:06:46.632194+02
\.


--
-- TOC entry 4037 (class 0 OID 16904)
-- Dependencies: 227
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.users (id, username, email, password_hash, phone, first_name, last_name, created_at, updated_at) FROM stdin;
0f722b0d-e7fb-4fbf-a5e2-7918842e8d80	testuser	test@madeinworld.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	\N	Test	User	2025-07-08 17:00:58.653866+02	2025-07-08 17:00:58.653866+02
\.


--
-- TOC entry 4030 (class 0 OID 16664)
-- Dependencies: 220
-- Data for Name: users_backup; Type: TABLE DATA; Schema: public; Owner: imsolesong
--

COPY public.users_backup (user_id, phone_number, password_hash, full_name, email, avatar_url, role, created_at, last_login, updated_at) FROM stdin;
\.


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 233
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 1, false);


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 210
-- Name: manufacturers_manufacturer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.manufacturers_manufacturer_id_seq', 7, true);


--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 218
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.notifications_notification_id_seq', 1, false);


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 212
-- Name: partners_partner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.partners_partner_id_seq', 1, false);


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 216
-- Name: product_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.product_categories_category_id_seq', 16, true);


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 225
-- Name: product_images_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.product_images_image_id_seq', 20, true);


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 223
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.products_product_id_seq', 20, true);


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 214
-- Name: stores_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.stores_store_id_seq', 16, true);


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 221
-- Name: subcategories_subcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: imsolesong
--

SELECT pg_catalog.setval('public.subcategories_subcategory_id_seq', 43, true);


--
-- TOC entry 3837 (class 2606 OID 16930)
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- TOC entry 3839 (class 2606 OID 16932)
-- Name: carts carts_user_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_product_id_key UNIQUE (user_id, product_id);


--
-- TOC entry 3858 (class 2606 OID 17041)
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- TOC entry 3860 (class 2606 OID 17043)
-- Name: inventory inventory_product_id_store_id_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_store_id_key UNIQUE (product_id, store_id);


--
-- TOC entry 3798 (class 2606 OID 16480)
-- Name: manufacturers manufacturers_company_name_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.manufacturers
    ADD CONSTRAINT manufacturers_company_name_key UNIQUE (company_name);


--
-- TOC entry 3800 (class 2606 OID 16478)
-- Name: manufacturers manufacturers_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.manufacturers
    ADD CONSTRAINT manufacturers_pkey PRIMARY KEY (manufacturer_id);


--
-- TOC entry 3813 (class 2606 OID 16644)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- TOC entry 3852 (class 2606 OID 16965)
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3847 (class 2606 OID 16951)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- TOC entry 3802 (class 2606 OID 16489)
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (partner_id);


--
-- TOC entry 3809 (class 2606 OID 16516)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (category_id);


--
-- TOC entry 3854 (class 2606 OID 17016)
-- Name: product_category_mapping product_category_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_category_mapping
    ADD CONSTRAINT product_category_mapping_pkey PRIMARY KEY (product_id, category_id);


--
-- TOC entry 3826 (class 2606 OID 16898)
-- Name: product_images product_images_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_pkey PRIMARY KEY (image_id);


--
-- TOC entry 3856 (class 2606 OID 17026)
-- Name: product_subcategory_mapping product_subcategory_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_subcategory_mapping
    ADD CONSTRAINT product_subcategory_mapping_pkey PRIMARY KEY (product_id, subcategory_id);


--
-- TOC entry 3820 (class 2606 OID 16875)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- TOC entry 3822 (class 2606 OID 16986)
-- Name: products products_product_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_product_uuid_unique UNIQUE (product_uuid);


--
-- TOC entry 3824 (class 2606 OID 16877)
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- TOC entry 3806 (class 2606 OID 16506)
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (store_id);


--
-- TOC entry 3817 (class 2606 OID 16841)
-- Name: subcategories subcategories_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_pkey PRIMARY KEY (subcategory_id);


--
-- TOC entry 3831 (class 2606 OID 16917)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3833 (class 2606 OID 16913)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3835 (class 2606 OID 16915)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3840 (class 1259 OID 16940)
-- Name: idx_carts_created_at; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_carts_created_at ON public.carts USING btree (created_at);


--
-- TOC entry 3841 (class 1259 OID 16939)
-- Name: idx_carts_product_id; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_carts_product_id ON public.carts USING btree (product_id);


--
-- TOC entry 3842 (class 1259 OID 16938)
-- Name: idx_carts_user_id; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_carts_user_id ON public.carts USING btree (user_id);


--
-- TOC entry 3810 (class 1259 OID 16655)
-- Name: idx_notifications_is_read; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_notifications_is_read ON public.notifications USING btree (is_read);


--
-- TOC entry 3811 (class 1259 OID 16654)
-- Name: idx_notifications_recipient; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_notifications_recipient ON public.notifications USING btree (recipient_user_id);


--
-- TOC entry 3848 (class 1259 OID 16976)
-- Name: idx_order_items_created_at; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_order_items_created_at ON public.order_items USING btree (created_at);


--
-- TOC entry 3849 (class 1259 OID 16974)
-- Name: idx_order_items_order_id; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_order_items_order_id ON public.order_items USING btree (order_id);


--
-- TOC entry 3850 (class 1259 OID 16975)
-- Name: idx_order_items_product_id; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_order_items_product_id ON public.order_items USING btree (product_id);


--
-- TOC entry 3843 (class 1259 OID 16973)
-- Name: idx_orders_created_at; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_orders_created_at ON public.orders USING btree (created_at);


--
-- TOC entry 3844 (class 1259 OID 16972)
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- TOC entry 3845 (class 1259 OID 16971)
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- TOC entry 3807 (class 1259 OID 16857)
-- Name: idx_product_categories_mini_app; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_product_categories_mini_app ON public.product_categories USING gin (mini_app_association);


--
-- TOC entry 3818 (class 1259 OID 16987)
-- Name: idx_products_product_uuid; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_products_product_uuid ON public.products USING btree (product_uuid);


--
-- TOC entry 3803 (class 1259 OID 16653)
-- Name: idx_stores_is_active; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_stores_is_active ON public.stores USING btree (is_active);


--
-- TOC entry 3804 (class 1259 OID 16652)
-- Name: idx_stores_type; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_stores_type ON public.stores USING btree (type);


--
-- TOC entry 3814 (class 1259 OID 16856)
-- Name: idx_subcategories_display_order; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_subcategories_display_order ON public.subcategories USING btree (display_order);


--
-- TOC entry 3815 (class 1259 OID 16855)
-- Name: idx_subcategories_parent_category; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_subcategories_parent_category ON public.subcategories USING btree (parent_category_id);


--
-- TOC entry 3827 (class 1259 OID 16920)
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- TOC entry 3828 (class 1259 OID 16919)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3829 (class 1259 OID 16918)
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: imsolesong
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- TOC entry 3879 (class 2620 OID 16989)
-- Name: carts update_carts_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_carts_updated_at BEFORE UPDATE ON public.carts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3873 (class 2620 OID 16658)
-- Name: manufacturers update_manufacturers_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_manufacturers_updated_at BEFORE UPDATE ON public.manufacturers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3880 (class 2620 OID 16990)
-- Name: orders update_orders_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3874 (class 2620 OID 16659)
-- Name: partners update_partners_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_partners_updated_at BEFORE UPDATE ON public.partners FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3876 (class 2620 OID 16661)
-- Name: product_categories update_product_categories_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_product_categories_updated_at BEFORE UPDATE ON public.product_categories FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3875 (class 2620 OID 16660)
-- Name: stores update_stores_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_stores_updated_at BEFORE UPDATE ON public.stores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3877 (class 2620 OID 16859)
-- Name: subcategories update_subcategories_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_subcategories_updated_at BEFORE UPDATE ON public.subcategories FOR EACH ROW EXECUTE FUNCTION public.update_subcategories_updated_at();


--
-- TOC entry 3878 (class 2620 OID 16988)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: imsolesong
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3866 (class 2606 OID 16933)
-- Name: carts carts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3871 (class 2606 OID 17044)
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 3872 (class 2606 OID 17049)
-- Name: inventory inventory_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(store_id) ON DELETE CASCADE;


--
-- TOC entry 3868 (class 2606 OID 16966)
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- TOC entry 3867 (class 2606 OID 16952)
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3861 (class 2606 OID 17054)
-- Name: product_categories product_categories_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(store_id);


--
-- TOC entry 3869 (class 2606 OID 17017)
-- Name: product_category_mapping product_category_mapping_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_category_mapping
    ADD CONSTRAINT product_category_mapping_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 3865 (class 2606 OID 16899)
-- Name: product_images product_images_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_images
    ADD CONSTRAINT product_images_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 3870 (class 2606 OID 17027)
-- Name: product_subcategory_mapping product_subcategory_mapping_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.product_subcategory_mapping
    ADD CONSTRAINT product_subcategory_mapping_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- TOC entry 3863 (class 2606 OID 16878)
-- Name: products products_manufacturer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_manufacturer_id_fkey FOREIGN KEY (manufacturer_id) REFERENCES public.manufacturers(manufacturer_id);


--
-- TOC entry 3864 (class 2606 OID 16883)
-- Name: products products_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(store_id) ON DELETE SET NULL;


--
-- TOC entry 3862 (class 2606 OID 16842)
-- Name: subcategories subcategories_parent_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: imsolesong
--

ALTER TABLE ONLY public.subcategories
    ADD CONSTRAINT subcategories_parent_category_id_fkey FOREIGN KEY (parent_category_id) REFERENCES public.product_categories(category_id) ON DELETE CASCADE;


-- Completed on 2025-07-09 21:33:11 CEST

--
-- PostgreSQL database dump complete
--

